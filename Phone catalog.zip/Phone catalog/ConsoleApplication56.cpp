﻿#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Phone
{
    string name;
    int price;
    int quantity;
};

void addPhone(vector<Phone>& phones)
{
    Phone p;
    cout << "Введите название: ";
    cin >> p.name;
    cout << "Введите цену: ";
    cin >> p.price;
    cout << "Введите количество: ";
    cin >> p.quantity;
    phones.push_back(p);
    cout << "Телефон добавлен.\n";
}

void showPhones(const vector<Phone>& phones)
{
    if (phones.empty()) {
        cout << "Список пуст.\n";
        return;
    }

    cout << "Название\tЦена\tКоличество\n";
    for (const Phone& p : phones) {
        cout << p.name << "\t" << p.price << "\t" << p.quantity << endl;
    }
}

void findPhone(const vector<Phone>& phones) {
    if (phones.empty()) {
        cout << "Список пуст.\n";
        return;
    }
    string name;
    cout << "Введите название: ";
    cin >> name;
    for (const Phone& p : phones) {
        if (p.name == name) {
            cout << "Найдено:\n";
            cout << "Название: " << p.name << endl;
            cout << "Цена: " << p.price << endl;
            cout << "Количество: " << p.quantity << endl;
            return;
        }
    }
    cout << "Телефон не найден.\n";
}

void totalPrice(const vector<Phone>& phones) {
    if (phones.empty()) {
        cout << "Список пуст.\n";
        return;
    }

    int sum = 0;
    for (const Phone& p : phones) {
        sum += p.price * p.quantity;
    }
    cout << "Общая стоимость: " << sum << endl;
}

void expensivePhone(const vector<Phone>& phones) {
    if (phones.empty()) {
        cout << "Список пуст.\n";
        return;
    }
  
    Phone maxPhone = phones[0];
    for (const Phone& p : phones) {
        if (p.price > maxPhone.price) {
            maxPhone = p;
        }
    }
    cout << "Самый дорогой телефон:\n";
    cout << "Название: " << maxPhone.name << endl;
    cout << "Цена: " << maxPhone.price << endl;
    cout << "Количество: " << maxPhone.quantity << endl;
}
int main() {
    setlocale(LC_ALL, "Russian");

    vector<Phone> phones;
    while (true) {
        int key;
            cout << "\n1 — Добавить телефон\n";
            cout << "2 — Показать все телефоны\n";
            cout << "3 — Найти телефон\n";
            cout << "4 — Общая стоимость\n";
            cout << "5 — Самый дорогой телефон\n";
            cout << "0 — Выход\n";
            cout << "Выбор: ";
            cin >> key;
            switch (key) {
            case 1:
                addPhone(phones);
                break;
            case 2:
                showPhones(phones);
                break;
            case 3:
                findPhone(phones);
                break;
            case 4:
                totalPrice(phones);
                break;
            case 5:
                expensivePhone(phones);
                break;
            case 0:
                cout << "Выход...\n";
                break;
            default:
                cout << "Ошибка выбора.\n";
            }
        }
    }